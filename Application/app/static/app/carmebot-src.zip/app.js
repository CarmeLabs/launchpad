/*-----------------------------------------------------------------------------
A simple echo bot for the Microsoft Bot Framework. Uses SDKv3 and formFlow for dialogue. 
-----------------------------------------------------------------------------*/

var restify = require('restify');
var builder = require('botbuilder');
var botbuilder_azure = require("botbuilder-azure");
var request = require("request");
require('dotenv').config()


// Setup Restify Server
var server = restify.createServer();
server.listen(process.env.port || process.env.PORT || 3978, function () {
    console.log('%s listening to %s', server.name, server.url);
});

// Create chat connector for communicating with the Bot Framework Service
var connector = new builder.ChatConnector({
    appId: process.env.MicrosoftAppId,
    appPassword: process.env.MicrosoftAppPassword,
    openIdMetadata: process.env.BotOpenIdMetadata
});

// Listen for messages from users 
server.post('/api/messages', connector.listen());

/*----------------------------------------------------------------------------------------
* Bot Storage: This is a great spot to register the private state storage for your bot. 
* We provide adapters for Azure Table, CosmosDb, SQL Azure, or you can implement your own!
* For samples and documentation, see: https://github.com/Microsoft/BotBuilder-Azure
* ---------------------------------------------------------------------------------------- */

var tableName = 'botdata';
var azureTableClient = new botbuilder_azure.AzureTableClient(tableName, process.env['AzureWebJobsStorage']);
var tableStorage = new botbuilder_azure.AzureBotStorage({ gzipData: false }, azureTableClient);

// Create bot with a function to receive messages from the user
var bot = new builder.UniversalBot(connector);
bot.set('storage', tableStorage);


// Creates the cluster. Activates once client is ready
function createCluster(name, clorgpu, num, auth, ok, failed) {
    console.log("Creating cluster");
    request.post({
        url: 'https://carmeonline.azurewebsites.net/api/projects',
        form: { cluster_name: 'name', "num_nodes": num, "max_nodes": num, "security": auth }
    },
        function (err, httpResponse, body) {
            if (err) {
                console.log("failed");
                console.log(err);
                failed();
            } else {
                console.log("ok");
                ok(JSON.parse(body).projectid);
            }
        });
};


// Beginning of bot dialogue. Calls initialDialogue at end.
bot.dialog('/', [
    function (session) {
        session.send("Hi! Welcome to the Carme Azure Chatbot.");
        session.beginDialog('initialDialogue');
    }
]);


// Asks info for first time.
bot.dialog('initialDialogue', [
    function (session) {
        session.beginDialog('askName');
    },
    function (session, results) {
        builder.Prompts.choice(session, "Hi " + results.response + "! What are you looking for?", ["Cluster", "GPU"]);
    },
    function (session, results) {
        session.userData.clgpu = results.response.entity;
        session.beginDialog('askStudents');
    },
    function (session, results) {
        session.beginDialog('askAuth');
    },
    function (session, results) {
        session.beginDialog('confirmationDialogue');
    },
    function (session, results) {
        session.endDialog();
    }
]);

// Confirms if info was correct.
bot.dialog('confirmationDialogue', [
    function (session, results) {
        var authtext = "authenticate them using " + session.userData.auth_method;
        if (session.userData.auth_method == "Internally") {
            authtext = "authenticate them internally";
        }
        else if (session.userData.auth_method == "I won't authenticate at all") {
            authtext = "not authenticate at all";
        }
        builder.Prompts.confirm(session, session.userData.name +
            ", you're looking for a " + session.userData.clgpu +
            ", you have " + session.userData.students +
            " students and will " + authtext + ". Is this correct?");
    },
    function (session, results) {
        if (results.response == true) {
            session.send("Awesome! Building...");
            createCluster(session.userData.name, session.userData.clgpu, session.userData.students, session.userData.auth_method,
                function (response) { console.log("yes"); session.send("Please visit https://carmeonline.azurewebsites.net/projects/" + response + " for status."); session.endDialog(); },
                function (response) { console.log("no"); session.send("Something went wrong. Please try again later."); session.endDialog(); });
        }
        else {
            builder.Prompts.choice(session, "What's wrong?", ["My name", "Cluster/GPU", "The number of students", "The authentication method"]);
        }
    },
    function (session, results) {
        session.userData.change = results.response.entity;
        session.beginDialog('somethingWrong');
    },
    function (session, results) {
        session.endDialog();
    }
]);

// User said something was wrong.
bot.dialog('somethingWrong', [
    function (session, results) {
        if (session.userData.change == "My name") {
            session.beginDialog('askName');
        }
        else if (session.userData.change == "Cluster/GPU") {
            session.beginDialog('changeCGPU');
        }
        else if (session.userData.change == "The number of students") {
            session.beginDialog('askStudents');
        }
        else if (session.userData.change == "The authentication method") {
            session.beginDialog('askAuth');
        }
    },
    function (session, results) {
        session.beginDialog('confirmationDialogue');
    },
    function (session, results) {
        session.endDialog();
    }
]);


// Asks user their name.
bot.dialog('askName', [
    function (session) {
        builder.Prompts.text(session, "What's your name?");
    },
    function (session, results) {
        session.userData.name = results.response;
        session.endDialogWithResult(results);
    }
]);


// Asks user for the number of users.
bot.dialog('askStudents', [
    function (session) {
        builder.Prompts.number(session, "How many students?");
    },
    function (session, results) {
        session.userData.students = results.response;
        session.endDialogWithResult(results);
    }
]);

// Asks user how they will authenticate
bot.dialog('askAuth', [
    function (session) {
        builder.Prompts.choice(session, "How will you authenticate?", ["Git", "SSH", "Single Password", "User Accounts with Individual Passwords", "Internally", "I won't authenticate at all"]);
    },
    function (session, results) {
        session.userData.auth_method = results.response.entity;
        session.endDialogWithResult(results);
    }
]);

// Changes user preference from Cluster to GPU or vice versa.
bot.dialog('changeCGPU', [
    function (session) {
        if (session.userData.clgpu == "Cluster") {
            session.send("Changing from Cluster to GPU.");
            session.userData.clgpu = "GPU";
        }
        else {
            session.send("Changing from GPU to Cluster.");
            session.userData.clgpu = "Cluster";
        }
        session.endDialogWithResult();
    }
]);